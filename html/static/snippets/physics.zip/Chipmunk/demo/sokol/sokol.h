#define SOKOL_WIN32_FORCE_MAIN
#define SOKOL_GLCORE33
#include "sokol_app.h"
#include "sokol_time.h"
#include "sokol_gfx.h"
