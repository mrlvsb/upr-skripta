var searchData=
[
  ['loadimage_3a',['loadImage:',['../interface_chipmunk_image_sampler.html#a84b93c6778e611c51171386768b8fd50',1,'ChipmunkImageSampler']]],
  ['localtoworld_3a',['localToWorld:',['../interface_chipmunk_body.html#acc335ffa19e7b7ae8eb7f19684431c76',1,'ChipmunkBody']]]
];
