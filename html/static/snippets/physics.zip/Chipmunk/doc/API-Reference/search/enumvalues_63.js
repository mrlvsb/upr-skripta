var searchData=
[
  ['cp_5fbody_5ftype_5fdynamic',['CP_BODY_TYPE_DYNAMIC',['../group__cp_body.html#gga3581b128fd3e2734952aeac8545fd5caa443c53c7b27e64799ee0eba728e60db6',1,'cpBody.h']]],
  ['cp_5fbody_5ftype_5fkinematic',['CP_BODY_TYPE_KINEMATIC',['../group__cp_body.html#gga3581b128fd3e2734952aeac8545fd5caa95e6c8d1ff2714d17bc4f2258407e58d',1,'cpBody.h']]],
  ['cp_5fbody_5ftype_5fstatic',['CP_BODY_TYPE_STATIC',['../group__cp_body.html#gga3581b128fd3e2734952aeac8545fd5caaa594879f082bbabce4bd16944f73456b',1,'cpBody.h']]]
];
