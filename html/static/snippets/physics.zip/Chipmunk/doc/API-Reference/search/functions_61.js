var searchData=
[
  ['activate',['activate',['../interface_chipmunk_body.html#a21bd1e326418c725ef27059e42df5056',1,'ChipmunkBody']]],
  ['activatestatic_3a',['activateStatic:',['../interface_chipmunk_body.html#afd233d8bff758debeff65163c9b63deb',1,'ChipmunkBody']]],
  ['add_3a',['add:',['../interface_chipmunk_space.html#a3c7c9546e958d23fac51a740ddfbfecd',1,'ChipmunkSpace']]],
  ['addbounds_3athickness_3aelasticity_3afriction_3afilter_3acollisiontype_3a',['addBounds:thickness:elasticity:friction:filter:collisionType:',['../interface_chipmunk_space.html#aba148d84cea04c5b2c438a6a643b313b',1,'ChipmunkSpace']]],
  ['addcollisionhandler_3atypea_3atypeb_3abegin_3apresolve_3apostsolve_3aseparate_3a',['addCollisionHandler:typeA:typeB:begin:preSolve:postSolve:separate:',['../interface_chipmunk_space.html#a44655d0695181e505c88e29afe676b31',1,'ChipmunkSpace']]],
  ['addpoint_3aradius_3afuzz_3a',['addPoint:radius:fuzz:',['../interface_chipmunk_point_cloud_sampler.html#a497e0117cba27c02057ecc8edf3f9347',1,'ChipmunkPointCloudSampler']]],
  ['addpoststepaddition_3a',['addPostStepAddition:',['../interface_chipmunk_space.html#afe4e87fa5df76a3e85dfe05d4bd917d0',1,'ChipmunkSpace']]],
  ['addpoststepblock_3akey_3a',['addPostStepBlock:key:',['../interface_chipmunk_space.html#a601fc53c6df561210fefedf9e6d5e2f0',1,'ChipmunkSpace']]],
  ['addpoststepcallback_3aselector_3akey_3a',['addPostStepCallback:selector:key:',['../interface_chipmunk_space.html#a70c4c5287cbf6321474c14cc811e094a',1,'ChipmunkSpace']]],
  ['addpoststepremoval_3a',['addPostStepRemoval:',['../interface_chipmunk_space.html#a64f0b58af1ee6de24086f05e31c958ea',1,'ChipmunkSpace']]],
  ['addtospace_3a',['addToSpace:',['../interface_chipmunk_body.html#acf26b9be2a1a4ed08caf5db486cfd3b2',1,'ChipmunkBody']]],
  ['applyforce_3aatlocalpoint_3a',['applyForce:atLocalPoint:',['../interface_chipmunk_body.html#a0a1200c2ad10278829a27172642d691f',1,'ChipmunkBody']]],
  ['applyimpulse_3aatlocalpoint_3a',['applyImpulse:atLocalPoint:',['../interface_chipmunk_body.html#aaaa07ba33b893cae6d0f4f9a1279bd39',1,'ChipmunkBody']]],
  ['aschipmunkpolyshapewithbody_3atransform_3aradius_3a',['asChipmunkPolyShapeWithBody:transform:radius:',['../interface_chipmunk_polyline.html#aef8225e947d0a9e1aa899697414a19b0',1,'ChipmunkPolyline']]],
  ['aschipmunksegmentswithbody_3aradius_3aoffset_3a',['asChipmunkSegmentsWithBody:radius:offset:',['../interface_chipmunk_polyline.html#a20e5b7eaeed6e4276c62524812bd3779',1,'ChipmunkPolyline']]]
];
