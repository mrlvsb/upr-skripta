var searchData=
[
  ['dampedrotaryspringwithbodya_3abodyb_3arestangle_3astiffness_3adamping_3a',['dampedRotarySpringWithBodyA:bodyB:restAngle:stiffness:damping:',['../interface_chipmunk_damped_rotary_spring.html#a808a43f3a6fdf400bb99e1fbd168551a',1,'ChipmunkDampedRotarySpring']]],
  ['dampedspringwithbodya_3abodyb_3aanchora_3aanchorb_3arestlength_3astiffness_3adamping_3a',['dampedSpringWithBodyA:bodyB:anchorA:anchorB:restLength:stiffness:damping:',['../interface_chipmunk_damped_spring.html#aa11a839f0a429dea60563eb8548617d0',1,'ChipmunkDampedSpring']]]
];
