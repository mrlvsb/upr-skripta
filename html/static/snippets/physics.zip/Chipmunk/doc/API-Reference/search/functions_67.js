var searchData=
[
  ['gearjointwithbodya_3abodyb_3aphase_3aratio_3a',['gearJointWithBodyA:bodyB:phase:ratio:',['../interface_chipmunk_gear_joint.html#a3a7335f5db5de91578546436de8b757c',1,'ChipmunkGearJoint']]],
  ['getvertex_3a',['getVertex:',['../interface_chipmunk_poly_shape.html#a22dd1d621e68fceacd34dc5f357883cb',1,'ChipmunkPolyShape']]],
  ['groovejointwithbodya_3abodyb_3agroovea_3agrooveb_3aanchorb_3a',['grooveJointWithBodyA:bodyB:grooveA:grooveB:anchorB:',['../interface_chipmunk_groove_joint.html#a1457262c2dc6954ffeeae7fd6545b41f',1,'ChipmunkGrooveJoint']]]
];
