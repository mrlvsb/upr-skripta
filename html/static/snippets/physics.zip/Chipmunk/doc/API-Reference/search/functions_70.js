var searchData=
[
  ['pinjointwithbodya_3abodyb_3aanchora_3aanchorb_3a',['pinJointWithBodyA:bodyB:anchorA:anchorB:',['../interface_chipmunk_pin_joint.html#ae8423ad0d6253568a2477a6bdf7f8d4a',1,'ChipmunkPinJoint']]],
  ['pivotjointwithbodya_3abodyb_3aanchora_3aanchorb_3a',['pivotJointWithBodyA:bodyB:anchorA:anchorB:',['../interface_chipmunk_pivot_joint.html#ae7fa4202f19fcb10b0bd8124c5142f1b',1,'ChipmunkPivotJoint']]],
  ['pivotjointwithbodya_3abodyb_3apivot_3a',['pivotJointWithBodyA:bodyB:pivot:',['../interface_chipmunk_pivot_joint.html#ab631c7ca9196d6cd6eef8c713887f7d9',1,'ChipmunkPivotJoint']]],
  ['pointqueryall_3amaxdistance_3afilter_3a',['pointQueryAll:maxDistance:filter:',['../interface_chipmunk_space.html#acf8ab8981d9b90e001c8fb1083bbcc08',1,'ChipmunkSpace']]],
  ['pointquerynearest_3amaxdistance_3afilter_3a',['pointQueryNearest:maxDistance:filter:',['../interface_chipmunk_space.html#a50246df09637c9b70e30c6c22c7892eb',1,'ChipmunkSpace']]],
  ['polywithbody_3acount_3averts_3atransform_3aradius_3a',['polyWithBody:count:verts:transform:radius:',['../interface_chipmunk_poly_shape.html#a5c780c8e7d0c9d5de65556df3084efa1',1,'ChipmunkPolyShape']]],
  ['postsolve_3a',['postSolve:',['../interface_chipmunk_constraint.html#a39ddc0c7f3b8994cbdc754caec26302b',1,'ChipmunkConstraint']]],
  ['presolve_3a',['preSolve:',['../interface_chipmunk_constraint.html#a98a5a76a31ec2af56e604050e7cc3d62',1,'ChipmunkConstraint']]]
];
