var searchData=
[
  ['alpha',['alpha',['../structcp_segment_query_info.html#af5b6ff0d0b32196cf2716e9672604c61',1,'cpSegmentQueryInfo']]]
];
