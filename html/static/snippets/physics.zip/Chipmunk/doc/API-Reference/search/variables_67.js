var searchData=
[
  ['gradient',['gradient',['../structcp_point_query_info.html#a55bf2732bc2563af6c83ce1985906034',1,'cpPointQueryInfo']]],
  ['group',['group',['../structcp_shape_filter.html#a6d29bf3cc7f406cdf834465f9de71c21',1,'cpShapeFilter']]]
];
