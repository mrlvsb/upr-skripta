#!/bin/bash

rm -f ./*.tga
for letter in {A..Z}; do
    convert \
     -background transparent \
     -fill white  \
     -stroke black \
     -strokewidth 1 \
     -font impact.ttf \
     -pointsize 40 \
     -trim \
     -alpha on \
     label:"$letter" \
     "$letter.tga"
done
