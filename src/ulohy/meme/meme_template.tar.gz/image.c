#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "image.h"

Image* image_new(int width, int height) {
    Image *img = malloc(sizeof(Image));
    if(img == NULL) {
        fprintf(stderr, "No memory\n");
        exit(1);
    }

    img->pixels = malloc(width * height * sizeof(Color));
    if(img->pixels == NULL) {
        fprintf(stderr, "No memory\n");
        exit(1);
    }

    // muzem nahradit nejakou fci co uz mame?
    memset(img->pixels, 0, width * height * sizeof(Color));

    img->width = width;
    img->height = height;
    return img;
}

void image_delete(Image* img) {
    free(img->pixels);
    free(img);
}

void image_rect(Image *img, int x, int y, int width, int height, Color fill) {
    for(int w = 0; w < width; w++) {
        for(int h = 0; h < height; h++) {
            int index = (y + h) * img->width + (x + w);
            img->pixels[index] = fill;
        }
    }
}