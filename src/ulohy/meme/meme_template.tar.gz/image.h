#pragma once

#include <stdint.h>

typedef struct {
    uint8_t r; // red, 0-255
    uint8_t g; // green, 0-255
    uint8_t b; // blue, 0-255
} Color;

typedef struct {
    int width;
    int height;
    Color *pixels;
} Image;

Image* image_new(int width, int height);
void image_delete(Image* img);
void image_rect(Image *img, int x, int y, int width, int height, Color fill);

/*
Color* image_at(Image *img, int x, int y);
void   image_set(Image *img, int x, int y, Color value);
Color  image_get(Image *img, int x, int y);
*/