#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include "sdl.h"

int main(int argc, char **argv) {
  int width = 800;
  int height = 600;
  srand(time(NULL));

  if(argc >= 2) {
    if(sscanf(argv[1], "%dx%d", &width, &height) != 2) {
      fprintf(stderr, "Usage: %s WxH\n", argv[0]);
      exit(1);
    }
  }

  // initialize SDL and create window (for details see sdl.h/sdl.c)
  SDL_Context *ctx = sdl_context_new("game", width, height);

  SDL_Texture *image = IMG_LoadTexture(ctx->renderer, "resources/snake-sprite.png");
  if (image == NULL) {
    fprintf(stderr, "Failed to load image: %s\n", SDL_GetError());
    return 1;
  }
  
  bool quit = false;
  Uint64 prevCounter = SDL_GetPerformanceCounter();
  while (!quit) {
    Uint64 now = SDL_GetPerformanceCounter();
    double elapsed_ms = (now - prevCounter) * 1000 / (double) SDL_GetPerformanceFrequency();
    prevCounter = now;

    SDL_Event e;
    while (SDL_PollEvent(&e)) {
      if (e.type == SDL_QUIT) {
        quit = true;
        break;
      }
      else if (e.type == SDL_KEYDOWN) {
        // key is pressed DOWN
        switch (e.key.keysym.sym) {
          case SDLK_ESCAPE:
          case SDLK_q:
            quit = true;
            break;
        }
      } else if(e.type == SDL_MOUSEMOTION) {
        // mouse move
        //printf("mouse x=%d y=%d\n", e.motion.x, e.motion.y);
      } else if(e.type == SDL_MOUSEBUTTONUP) {
        // e.button.button: SDL_BUTTON_LEFT, SDL_BUTTON_MIDDLE, SDL_BUTTON_RIGHT
        //printf("mouse x=%d y=%d button=%d\n", e.button.x, e.button.y, e.button.button);
      }
    }

    // clear the buffer
    SDL_SetRenderDrawColor(ctx->renderer, 0, 0, 0, 255);
    SDL_RenderClear(ctx->renderer);

    // your code here

    // show the buffer
    SDL_RenderPresent(ctx->renderer);
  }


  // cleanup all resources
  SDL_DestroyTexture(image);
  sdl_context_delete(ctx);
  return 0;
}
